import firebase_admin
from firebase_admin import credentials, firestore
import json
from datetime import datetime

def upload_synthetic_data():
    # Initialize Firebase
    try:
        cred = credentials.Certificate('serviceAccountKey.json')
        firebase_admin.initialize_app(cred)
    except Exception as e:
        print(f"Error initializing Firebase: {e}")
        print("Make sure serviceAccountKey.json is in the same directory")
        return
    
    db = firestore.client()
    
    # Load the generated data
    try:
        with open('workout_dataset.json', 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        print("Error: workout_dataset.json not found")
        print("Run generate_synthetic_data.py first")
        return
    
    print(f"Uploading {len(data)} samples to Firestore...")
    success_count = 0
    error_count = 0
    
    for i, sample in enumerate(data):
        try:
            # Prepare the document data with correct structure
            feedback_doc = {
                'userId': sample.get('userId', f'synthetic_user_{i}'),
                'workoutPlanId': sample.get('workoutPlanId', f'synthetic_plan_{i}'),
                'completionRate': float(sample.get('completionRate', 0.5)),
                'difficultyRating': int(sample.get('difficultyRating', 3)),
                'effectivenessRating': int(sample.get('effectivenessRating', 3)),
                'injuryOccurred': bool(sample.get('injuryOccurred', False)),
                'daysCompleted': int(sample.get('daysCompleted', 0)),
                'feedbackText': sample.get('feedbackText', 'Synthetic feedback'),
                'userAge': int(sample.get('age', 25)),
                'userWeight': float(sample.get('weight', 70.0)),
                'userHeight': float(sample.get('height', 170.0)),
                'fitnessLevel': sample.get('fitnessLevel', 'Intermediate'),
                'workoutDuration': sample.get('workoutDuration', 'Week'),
                'createdAt': datetime.now()  # Use current timestamp
            }
            
            # Upload to Firestore
            db.collection('workoutFeedback').add(feedback_doc)
            success_count += 1
            
            if (i + 1) % 50 == 0:
                print(f"Uploaded {i + 1} samples... ({success_count} successful, {error_count} errors)")
        
        except Exception as e:
            error_count += 1
            if error_count <= 5:  # Only print first 5 errors
                print(f"Error uploading sample {i}: {e}")
    
    print(f"\nUpload complete!")
    print(f"Successful: {success_count}")
    print(f"Errors: {error_count}")
    print(f"\nGo to Firebase Console to verify:")
    print("https://console.firebase.google.com → Firestore Database → workoutFeedback")

if __name__ == '__main__':
    upload_synthetic_data()
