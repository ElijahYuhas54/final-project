# Workout AI App - Setup Instructions

## Firebase Configuration

1. **Create Firebase Project**
   - Go to https://console.firebase.google.com/
   - Create a new project or use an existing one
   - Add an iOS app to your Firebase project

2. **Download GoogleService-Info.plist**
   - In Firebase Console, go to Project Settings
   - Download the GoogleService-Info.plist file
   - Replace the placeholder file in the project with your downloaded file

3. **Enable Firebase Services**
   - Enable Authentication (Email/Password)
   - Enable Firestore Database
   - Enable Vertex AI (Gemini) in Firebase Extensions

4. **Firestore Security Rules**
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
       match /workoutPlans/{planId} {
         allow read, write: if request.auth != null && 
           resource.data.userId == request.auth.uid;
       }
     }
   }
   ```

## Xcode Setup

1. **Open Project in Xcode**
   - Open Xcode 15 or later
   - Create a new iOS App project
   - Name it "WorkoutAIApp"
   - Set minimum deployment target to iOS 16.0

2. **Add Swift Files**
   - Add all provided .swift files to your Xcode project
   - Organize them in appropriate folders (Models, ViewModels, Views)

3. **Add Firebase SDK via Swift Package Manager**
   - In Xcode: File → Add Package Dependencies
   - Add: https://github.com/firebase/firebase-ios-sdk.git
   - Select the following packages:
     - FirebaseAuth
     - FirebaseFirestore
     - FirebaseVertexAI
   - Version: 10.20.0 or later

4. **Add GoogleService-Info.plist**
   - Drag your downloaded GoogleService-Info.plist into Xcode
   - Ensure "Copy items if needed" is checked
   - Add to target: WorkoutAIApp

5. **Configure Bundle Identifier**
   - Match your Firebase iOS app bundle identifier
   - Example: com.yourcompany.WorkoutAIApp

## Project Structure

```
WorkoutAIApp/
├── WorkoutAIApp.swift (Main App)
├── ContentView.swift
├── GoogleService-Info.plist
├── Info.plist
├── Models/
│   ├── UserProfile.swift
│   └── WorkoutPlan.swift
├── ViewModels/
│   ├── AuthViewModel.swift
│   ├── UserViewModel.swift
│   └── WorkoutViewModel.swift
└── Views/
    ├── AuthenticationView.swift
    ├── MainTabView.swift
    ├── HomeView.swift
    ├── ProfileView.swift
    ├── ProfileSetupView.swift
    ├── EditProfileView.swift
    ├── WorkoutPlansView.swift
    ├── WorkoutPlanDetailView.swift
    └── GeneratedPlanView.swift
```

## Features

- User authentication with persistent login
- Profile management (weight, height, age, fitness level, goals)
- AI-powered workout plan generation using Gemini
- Multiple duration options (Day, Week, Month, Year)
- Storage of all generated workout plans
- View and delete past workout plans
- Share workout plans

## Running the App

1. Ensure all Firebase services are properly configured
2. Build and run the app in Xcode
3. Create an account or sign in
4. Set up your profile with physical and fitness information
5. Generate personalized workout plans

## Dependencies

- iOS 16.0+
- Xcode 15.0+
- Firebase iOS SDK 10.20.0+
  - FirebaseAuth
  - FirebaseFirestore
  - FirebaseVertexAI (includes Gemini AI)

## Notes

- The app uses Firebase Vertex AI which provides built-in access to Google's Gemini model
- No separate Gemini API key is needed when using Firebase Vertex AI
- User authentication is persistent across app launches
- All user data and workout plans are stored securely in Firestore
