# Firebase Setup Guide for Workout AI App

## Complete Firebase Configuration Steps

### Part 1: Create Firebase Project

1. **Go to Firebase Console**
   - Visit: https://console.firebase.google.com/
   - Sign in with your Google account

2. **Create New Project**
   - Click "Add project" or "Create a project"
   - Enter project name: `workout-ai-app` (or your preferred name)
   - Click "Continue"
   
3. **Google Analytics (Optional)**
   - Choose whether to enable Google Analytics
   - If enabled, select or create an Analytics account
   - Click "Create project"
   - Wait for project creation to complete (30-60 seconds)

---

### Part 2: Add iOS App to Firebase

1. **Register Your iOS App**
   - In Firebase Console, click the iOS icon (⊕ Add app)
   - Enter your iOS bundle ID: `com.yourcompany.WorkoutAIApp`
     - **IMPORTANT**: This must match exactly with your Xcode project
     - To find it: Xcode → Select your project → General tab → Bundle Identifier
   
2. **App Nickname** (Optional)
   - Enter: "Workout AI iOS" or leave blank
   
3. **App Store ID** (Optional)
   - Leave blank for now (only needed when publishing)
   
4. **Click "Register app"**

---

### Part 3: Download GoogleService-Info.plist

1. **Download Configuration File**
   - Click "Download GoogleService-Info.plist"
   - Save the file to your computer
   
2. **Add to Xcode Project**
   - Open your Xcode project
   - Drag `GoogleService-Info.plist` into the Xcode project navigator
   - **CRITICAL SETTINGS**:
     ✅ Check "Copy items if needed"
     ✅ Select your app target (WorkoutAIApp)
     ✅ Ensure it's in the root of your project, not in a subfolder
   
3. **Verify Installation**
   - In Xcode Project Navigator, you should see `GoogleService-Info.plist`
   - Click on it to verify it has content (API keys, project IDs, etc.)

4. **Click "Next" in Firebase Console**

---

### Part 4: Add Firebase SDK to Xcode

1. **Open Your Xcode Project**
   - Launch Xcode
   - Open WorkoutAIApp.xcodeproj

2. **Add Firebase Package**
   - File → Add Package Dependencies...
   - In the search bar, paste: `https://github.com/firebase/firebase-ios-sdk.git`
   - Click "Add Package"
   
3. **Select Package Version**
   - Dependency Rule: "Up to Next Major Version"
   - Version: 10.20.0 or higher
   - Click "Add Package"
   
4. **Choose Firebase Products** (Select these specific packages):
   ✅ **FirebaseAuth** - For user authentication
   ✅ **FirebaseFirestore** - For database storage
   ✅ **FirebaseVertexAI** - For Gemini AI integration
   
   Click "Add Package"
   
5. **Wait for Installation**
   - Xcode will download and integrate the packages
   - This may take 1-3 minutes

6. **Click "Next" in Firebase Console**
   - You can skip the initialization code section (already done in WorkoutAIApp.swift)
   - Click "Continue to console"

---

### Part 5: Enable Firebase Authentication

1. **Navigate to Authentication**
   - In Firebase Console, left sidebar → Build → Authentication
   - Click "Get started"

2. **Enable Email/Password Sign-In**
   - Click "Sign-in method" tab
   - Find "Email/Password" in the list
   - Click on it
   - Toggle "Enable" to ON
   - Toggle "Email link (passwordless sign-in)" to OFF (leave disabled)
   - Click "Save"

3. **Verify Configuration**
   - You should see "Email/Password" listed as "Enabled"

---

### Part 6: Set Up Cloud Firestore Database

1. **Navigate to Firestore**
   - In Firebase Console, left sidebar → Build → Firestore Database
   - Click "Create database"

2. **Choose Database Mode**
   - Select "Start in test mode" (for development)
   - Click "Next"
   
   **IMPORTANT**: Test mode allows read/write access for 30 days. 
   We'll update security rules in the next step.

3. **Select Location**
   - Choose a Cloud Firestore location closest to your users
   - Recommended for US: `us-central1` (Iowa)
   - **NOTE**: This cannot be changed later
   - Click "Enable"
   
4. **Wait for Database Creation**
   - This takes 30-60 seconds

5. **Update Security Rules**
   - Click "Rules" tab
   - Replace the default rules with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // User profiles - only owner can read/write
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Workout plans - only owner can read/write
    match /workoutPlans/{planId} {
      allow read, write: if request.auth != null && 
        resource.data.userId == request.auth.uid;
      allow create: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
    }
    
    // Workout feedback - only owner can write, all authenticated users can read
    // (needed for ML training)
    match /workoutFeedback/{feedbackId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
    }
    
    // Workout progress - only owner can read/write
    match /workoutProgress/{progressId} {
      allow read, write: if request.auth != null && 
        resource.data.userId == request.auth.uid;
      allow create: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
    }
    
    // Model training logs - all authenticated users can read
    match /modelTrainingLogs/{logId} {
      allow read: if request.auth != null;
      allow write: if false; // Only app backend can write
    }
  }
}
```

6. **Publish Rules**
   - Click "Publish"
   - Confirm the changes

---

### Part 7: Enable Firebase Vertex AI (Gemini)

1. **Navigate to Vertex AI**
   - In Firebase Console, left sidebar → Build → Vertex AI in Firebase
   - Or go to: https://console.firebase.google.com/project/YOUR_PROJECT_ID/genai

2. **Enable Vertex AI API**
   - Click "Get started" or "Enable"
   - You may be prompted to upgrade to Blaze plan (pay-as-you-go)
   - **IMPORTANT**: Vertex AI requires Blaze plan, but has generous free tier

3. **Upgrade to Blaze Plan** (If Required)
   - Click "Upgrade project"
   - Select "Blaze (Pay as you go)"
   - Add billing information (credit card required)
   - **Don't worry**: Free tier includes:
     - 15 free requests per minute
     - 1,500 free requests per day
     - Generous token limits
   - Click "Purchase"

4. **Enable Vertex AI in Firebase**
   - After billing setup, return to Vertex AI page
   - Click "Enable Vertex AI API"
   - Wait for enablement (30 seconds)

5. **Verify Gemini Model Access**
   - You should see "gemini-1.5-flash" and "gemini-1.5-pro" listed
   - These models are now available in your app

---

### Part 8: Create Firestore Indexes (For Query Performance)

1. **Navigate to Firestore Indexes**
   - In Firebase Console → Firestore Database → Indexes tab

2. **Create Composite Index for Workout Plans**
   - Click "Create Index" or "Add Index"
   - Collection ID: `workoutPlans`
   - Fields to index:
     - Field: `userId`, Order: Ascending
     - Field: `createdAt`, Order: Descending
   - Query scope: Collection
   - Click "Create"
   - Wait for index to build (2-5 minutes)

3. **Create Index for Workout Feedback**
   - Click "Create Index"
   - Collection ID: `workoutFeedback`
   - Fields to index:
     - Field: `userId`, Order: Ascending
     - Field: `createdAt`, Order: Descending
   - Query scope: Collection
   - Click "Create"

**Note**: You may also create these indexes automatically when you run queries in your app. 
Firebase will prompt you with a link if an index is needed.

---

### Part 9: Configure App Settings

1. **Update Bundle Identifier in Xcode**
   - Open Xcode
   - Select your project in the navigator
   - Select your target (WorkoutAIApp)
   - General tab → Identity
   - Ensure Bundle Identifier matches what you entered in Firebase
   - Example: `com.yourcompany.WorkoutAIApp`

2. **Set Minimum iOS Version**
   - In same screen, set "Minimum Deployments" to iOS 16.0 or higher
   - Firebase Vertex AI requires iOS 15.0+, but iOS 16.0 recommended

3. **Add Required Capabilities** (if not already present)
   - Select your target → Signing & Capabilities tab
   - Click "+ Capability"
   - Add "Background Modes" (if you want background sync)
   - Check "Background fetch" and "Remote notifications"

---

### Part 10: Test Firebase Connection

1. **Build and Run Your App**
   - Connect your iPhone or use the Simulator
   - Click the "Play" button in Xcode (or Cmd+R)
   - Watch the console for Firebase initialization logs

2. **Expected Console Output**
   ```
   [Firebase/Analytics] Analytics enabled
   [Firebase/Auth] Auth initialized
   [Firebase/Firestore] Firestore initialized
   ```

3. **Test Authentication**
   - In the app, try to sign up with a test email
   - Example: test@example.com / Password123
   - Check Firebase Console → Authentication → Users
   - You should see the new user listed

4. **Test Firestore Write**
   - After signing up, create your profile
   - Enter weight, height, age, fitness level, goals
   - Save profile
   - Check Firebase Console → Firestore Database → Data tab
   - You should see a new document in the `users` collection

5. **Test Gemini AI**
   - Complete your profile setup
   - Try generating a workout plan
   - Wait for the AI response
   - If successful, you'll see a generated workout plan

---

### Part 11: Monitor Usage (Important!)

1. **Set Budget Alerts**
   - Go to Google Cloud Console: https://console.cloud.google.com/
   - Select your Firebase project
   - Navigation menu → Billing → Budgets & alerts
   - Click "Create Budget"
   - Set amount: $10 (or your preferred limit)
   - Configure alert thresholds: 50%, 90%, 100%
   - Add your email for notifications
   - Click "Finish"

2. **Monitor Vertex AI Usage**
   - Firebase Console → Vertex AI → Usage tab
   - Check daily request counts
   - Ensure you're within free tier limits

3. **Monitor Firestore Usage**
   - Firebase Console → Firestore → Usage tab
   - Check document reads/writes
   - Free tier: 50,000 reads, 20,000 writes per day

---

### Part 12: Firebase Configuration Checklist

Before deploying or sharing your app, verify:

✅ **Authentication**
- [ ] Email/Password sign-in enabled
- [ ] Test user can sign up and sign in
- [ ] Persistent login works (close and reopen app)

✅ **Firestore Database**
- [ ] Database created in preferred location
- [ ] Security rules updated and published
- [ ] Test data writes successfully
- [ ] Composite indexes created for queries

✅ **Vertex AI (Gemini)**
- [ ] Blaze plan enabled
- [ ] Vertex AI API enabled
- [ ] Budget alerts configured
- [ ] Test workout plan generation works

✅ **Xcode Configuration**
- [ ] GoogleService-Info.plist added to project
- [ ] Bundle identifier matches Firebase
- [ ] Firebase packages installed (Auth, Firestore, VertexAI)
- [ ] App builds without errors

✅ **Testing**
- [ ] Sign up new user works
- [ ] Profile creation/update works
- [ ] Workout plan generation works
- [ ] Workout plans saved to Firestore
- [ ] ML feedback submission works

---

### Common Issues and Solutions

**Issue 1: "FirebaseApp.configure() failed"**
- **Solution**: Ensure GoogleService-Info.plist is in the project root
- Verify it's included in the target's Copy Bundle Resources

**Issue 2: "User not authenticated"**
- **Solution**: Check Firebase Console → Authentication
- Ensure Email/Password provider is enabled

**Issue 3: "Permission denied" in Firestore**
- **Solution**: Update security rules as shown in Part 6
- Verify rules are published

**Issue 4: "Vertex AI not available"**
- **Solution**: Upgrade to Blaze plan
- Enable Vertex AI API in Firebase Console

**Issue 5: "Index not found" error**
- **Solution**: Click the link in the error message
- Or manually create indexes as shown in Part 8

**Issue 6: Module 'FirebaseVertexAI' not found**
- **Solution**: Ensure you selected FirebaseVertexAI when adding packages
- Try: File → Packages → Reset Package Caches
- Clean build folder: Product → Clean Build Folder (Cmd+Shift+K)

**Issue 7: Build errors after adding Firebase**
- **Solution**: Increase minimum iOS version to 16.0
- Update Xcode to latest version (15.0+)

---

### Firebase Pricing Overview (Current as of 2024)

**Free Tier (Spark Plan)**
- Authentication: Unlimited users
- Firestore: 50K reads, 20K writes, 1GB storage per day
- Vertex AI: NOT available (requires Blaze plan)

**Blaze Plan (Pay-as-you-go)**
- Everything in Spark, plus:
- **Vertex AI (Gemini)**:
  - First 1,500 requests/day: FREE
  - After that: ~$0.001-0.002 per request
- **Firestore**: Same free limits, then:
  - Reads: $0.06 per 100K
  - Writes: $0.18 per 100K
  - Storage: $0.18 per GB/month

**Estimated Monthly Cost for Small App**
- 100 active users
- 10 workout plans generated per user per month = 1,000 AI requests
- **Cost**: $0-2/month (likely FREE with daily limits)

**Recommended Budget**: $10/month with alerts at $5

---

### Security Best Practices

1. **Never commit GoogleService-Info.plist to public repositories**
   - Add to .gitignore if using Git
   - Each developer should download their own copy

2. **Use proper Firestore security rules**
   - Never use `allow read, write: if true;` in production
   - Always verify `request.auth.uid`

3. **Enable App Check** (Optional, Advanced)
   - Protects your backend from abuse
   - Firebase Console → Build → App Check

4. **Rotate API keys if compromised**
   - Firebase Console → Project Settings → Service Accounts
   - Generate new keys

---

### Next Steps After Setup

1. **Test all features thoroughly**
2. **Collect real user feedback data**
3. **Monitor Firebase usage daily for first week**
4. **Adjust budget alerts as needed**
5. **Consider enabling App Check before production launch**

---

### Support Resources

- **Firebase Documentation**: https://firebase.google.com/docs/ios/setup
- **Vertex AI Docs**: https://firebase.google.com/docs/vertex-ai
- **Firestore Security Rules**: https://firebase.google.com/docs/firestore/security/get-started
- **Stack Overflow**: Tag questions with `firebase`, `swiftui`, `vertex-ai`
- **Firebase Support**: https://firebase.google.com/support

---

## Quick Setup Checklist

1. [ ] Create Firebase project
2. [ ] Add iOS app with bundle ID
3. [ ] Download GoogleService-Info.plist
4. [ ] Add plist to Xcode project
5. [ ] Add Firebase packages via SPM
6. [ ] Enable Email/Password authentication
7. [ ] Create Firestore database
8. [ ] Update Firestore security rules
9. [ ] Upgrade to Blaze plan
10. [ ] Enable Vertex AI
11. [ ] Set budget alerts
12. [ ] Build and test app
13. [ ] Verify all features work

**Estimated Setup Time**: 30-45 minutes

Good luck with your Workout AI app! 🚀
