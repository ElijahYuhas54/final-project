# Machine Learning Pipeline for Workout AI App

## Overview

This document describes the complete machine learning pipeline integrated into the Workout AI app, including dataset creation, model training/testing using Google Gemini, and evaluation metrics.

---

## 3. System Description

### Dataset

**What is the dataset?**
The dataset consists of user workout feedback data collected directly from the Workout AI app. Each data point represents a completed workout plan with user characteristics and outcome metrics.

**Data Structure:**
- **User Physical Attributes**: Age, Weight (kg), Height (cm)
- **Fitness Information**: Fitness Level (Beginner/Intermediate/Advanced/Professional)
- **Workout Details**: Duration (Day/Week/Month/Year)
- **Outcome Metrics**: 
  - Completion Rate (0-1): Percentage of workout completed
  - Difficulty Rating (1-5): User-reported difficulty
  - Effectiveness Rating (1-5): User-reported effectiveness
  - Injury Occurred (Boolean): Whether any injury occurred
  - Days Completed: Number of days user followed the plan

**Dataset Size:**
- Initial training requires minimum 100 samples
- Recommended 500+ samples for production use
- Real-world data collected from actual app users

### AI Model Selection

**Chosen Model: Google Gemini 1.5 Flash (via Firebase Vertex AI)**

**Why Gemini?**
1. **Zero-Shot Learning**: Can make predictions without extensive pre-training
2. **Natural Language Understanding**: Processes user characteristics and patterns contextually
3. **Built-in Firebase Integration**: No separate API setup required
4. **Cost-Effective**: Firebase provides generous free tier
5. **Reasoning Capability**: Can explain predictions and adapt to new patterns
6. **No Training Infrastructure**: Uses prompt engineering instead of traditional ML training

**Alternative Models Considered:**
- **Random Forest**: Good for structured data but requires manual feature engineering
- **Neural Networks**: Would require extensive training data and computational resources
- **XGBoost**: Strong performance but less explainable than Gemini
- **Decision**: Gemini chosen for ease of integration, explainability, and rapid iteration

### Implementation Steps

**Data Collection:**
- Users submit feedback after completing workout plans through the app
- Feedback includes completion metrics, difficulty ratings, and safety information
- Data automatically stored in Firebase Firestore
- Privacy-preserved: User identifiers are anonymized

**Pre-processing:**
- Data cleaning: Remove invalid entries (negative values, missing fields)
- Normalization: Standardize weight/height ranges
- Outlier removal: Filter extreme values that may indicate data entry errors
- Encoding: Convert categorical variables (fitness level, duration) to numerical representations
- Balancing: Ensure equal representation of successful vs unsuccessful workouts
- Train/Test Split: 80% training, 20% testing (randomized)

**Data Flow:**
```
User Completes Workout 
    → Submit Feedback (WorkoutFeedbackView)
    → Store in Firestore (DataCollectionService)
    → Clean & Normalize (DataPreprocessor)
    → Train/Test Split
    → Model Training (Gemini API)
    → Model Testing & Evaluation
    → Display Metrics (ModelEvaluationView)
```

---

## 4. Methodology / Pipeline

### Data Preparation

**1. Data Cleaning:**
```swift
// Validation rules applied
- Age: 13-80 years
- Weight: 30-200 kg
- Height: 120-230 cm
- Completion Rate: 0-1 (0-100%)
- Ratings: 1-5 scale
- Remove entries with missing critical fields
```

**2. Data Encoding:**
- Fitness Level → Integer (1=Beginner, 2=Intermediate, 3=Advanced, 4=Professional)
- Duration → Days (1=Day, 7=Week, 30=Month, 365=Year)
- Injury → Binary (0=No, 1=Yes)

**3. Data Splitting:**
- Training Set: 80% of cleaned data
- Test Set: 20% of cleaned data
- Randomized shuffle to prevent bias
- Stratified to maintain class balance

**4. Data Balancing:**
- Identify successful workouts (completion ≥70% AND no injury)
- Identify unsuccessful workouts (completion <70% OR injury)
- Balance classes to prevent model bias toward majority class

### Model Training

**Training Process with Gemini:**

1. **Prepare Training Prompt:**
   - Include dataset summary statistics
   - Provide sample training data (first 100 examples)
   - Define learning objectives and patterns to identify

2. **Pattern Learning:**
   Gemini learns to identify:
   - Which user profiles successfully complete specific workout durations
   - Correlation between difficulty ratings and completion rates
   - Combinations that lead to injuries (safety patterns)
   - Effectiveness indicators for optimal workout assignment

3. **Training Execution:**
   ```
   Input: Training dataset with user profiles and outcomes
   Process: Gemini analyzes patterns via prompt engineering
   Output: Learned patterns and key insights
   ```

4. **Training Storage:**
   - Training logs saved to Firestore
   - Model version tracked
   - Training timestamp recorded

### Model Testing

**Testing Process:**

1. **Prediction Generation:**
   For each test sample:
   - Input: User profile (age, weight, height, fitness level, desired duration)
   - Process: Gemini generates prediction based on learned patterns
   - Output: JSON with predicted outcomes

2. **Prediction Format:**
   ```json
   {
     "recommendedDuration": "Week",
     "expectedCompletionRate": 0.85,
     "estimatedDifficulty": 3,
     "safetyScore": 0.92,
     "confidence": 0.88
   }
   ```

3. **Comparison:**
   - Compare predicted outcomes with actual outcomes
   - Classify as True/False Positive/Negative
   - Calculate evaluation metrics

### Evaluation Metrics

**Primary Metrics:**

1. **Accuracy**: (TP + TN) / Total
   - Percentage of correct predictions
   - Target: ≥75%

2. **Precision**: TP / (TP + FP)
   - Of all positive predictions, how many were correct?
   - Important for avoiding false recommendations
   - Target: ≥70%

3. **Recall**: TP / (TP + FN)
   - Of all actual positives, how many did we catch?
   - Important for catching all successful workout matches
   - Target: ≥70%

4. **F1 Score**: 2 × (Precision × Recall) / (Precision + Recall)
   - Harmonic mean of precision and recall
   - Balanced metric for overall performance
   - Target: ≥70%

**Confusion Matrix:**
```
                Predicted Positive    Predicted Negative
Actual Positive      TP                     FN
Actual Negative      FP                     TN
```

Where:
- TP (True Positive): Correctly predicted successful workout
- TN (True Negative): Correctly predicted unsuccessful workout
- FP (False Positive): Predicted success but actually unsuccessful
- FN (False Negative): Predicted failure but actually successful

**Visual Metrics:**
- Bar charts showing metric percentages
- Confusion matrix heatmap
- Distribution charts for dataset statistics

---

## 5. Implementation Results

### Project Visualization

The app provides several visualization components:

1. **Dataset Dashboard:**
   - Total samples collected
   - Dataset readiness status
   - Export functionality for external analysis

2. **Training Progress:**
   - Real-time training status
   - Key insights learned by the model
   - Training completion confirmation

3. **Evaluation Metrics Display:**
   - Accuracy, Precision, Recall, F1 Score bars with percentages
   - Color-coded progress bars (Blue, Green, Orange, Purple)
   - Numerical values displayed prominently

4. **Confusion Matrix Visualization:**
   - 2×2 grid showing TP, TN, FP, FN
   - Color-coded cells (Green for correct, Orange for incorrect)
   - Labels indicating prediction vs actual

### How to Obtain Data

**Method 1: Real User Data Collection (Recommended)**

1. Deploy the app to TestFlight or App Store
2. Recruit beta testers or real users
3. Users generate workout plans and complete them
4. Users submit feedback via the app
5. Data automatically collects in Firestore
6. **Timeline**: 2-4 weeks to gather 100+ samples

**Method 2: Synthetic Data Generation (For Testing)**

Create a Python script to generate realistic synthetic data:

```python
import random
import firebase_admin
from firebase_admin import firestore
import datetime

# Initialize Firebase
cred = firebase_admin.credentials.Certificate('path/to/serviceAccountKey.json')
firebase_admin.initialize_app(cred)
db = firestore.client()

fitness_levels = ['Beginner', 'Intermediate', 'Advanced', 'Professional']
durations = ['Day', 'Week', 'Month', 'Year']

def generate_sample():
    age = random.randint(18, 65)
    weight = random.uniform(50, 120)
    height = random.uniform(150, 200)
    fitness_level = random.choice(fitness_levels)
    duration = random.choice(durations)
    
    # Generate realistic correlations
    base_completion = 0.7
    if fitness_level == 'Beginner' and duration in ['Month', 'Year']:
        base_completion -= 0.2
    if fitness_level in ['Advanced', 'Professional']:
        base_completion += 0.1
    
    completion_rate = max(0.1, min(1.0, base_completion + random.uniform(-0.2, 0.2)))
    difficulty_rating = random.randint(1, 5)
    effectiveness_rating = random.randint(1, 5)
    injury_occurred = random.random() < 0.05  # 5% injury rate
    days_completed = int(completion_rate * {'Day': 1, 'Week': 7, 'Month': 30, 'Year': 365}[duration])
    
    return {
        'userId': f'user_{random.randint(1, 1000)}',
        'workoutPlanId': f'plan_{random.randint(1, 10000)}',
        'completionRate': completion_rate,
        'difficultyRating': difficulty_rating,
        'effectivenessRating': effectiveness_rating,
        'injuryOccurred': injury_occurred,
        'daysCompleted': days_completed,
        'feedbackText': 'Generated sample',
        'userAge': age,
        'userWeight': weight,
        'userHeight': height,
        'fitnessLevel': fitness_level,
        'workoutDuration': duration,
        'createdAt': datetime.datetime.now()
    }

# Generate 500 samples
for i in range(500):
    sample = generate_sample()
    db.collection('workoutFeedback').add(sample)
    if i % 50 == 0:
        print(f'Generated {i} samples...')

print('Data generation complete!')
```

**Method 3: Public Fitness Datasets (Adaptation Required)**

Available datasets that could be adapted:
- **MyFitnessPal Dataset**: Food and exercise logs
- **Fitbit Public Dataset**: Activity and health metrics
- **UCI Machine Learning Repository**: Physical Activity Recognition
- **Kaggle Fitness Datasets**: Various workout-related datasets

**Note**: Public datasets require significant preprocessing to match the app's schema.

### Data Preparation Steps

**Step-by-Step Process:**

1. **Collection** (Automatic in App):
   - Users submit feedback via `WorkoutFeedbackView`
   - Data saved to Firestore collection `workoutFeedback`

2. **Export** (Manual):
   - Open ModelEvaluationView in app
   - Tap "Export Dataset (CSV)"
   - Share/save CSV file for external analysis

3. **Preprocessing** (Automatic in App):
   ```swift
   let preprocessor = DataPreprocessor()
   let cleaned = preprocessor.cleanAndNormalize(feedbackList: rawData)
   let filtered = preprocessor.removeOutliers(data: cleaned)
   let balanced = preprocessor.balanceDataset(data: filtered)
   let (train, test) = preprocessor.splitTrainTest(data: balanced, testRatio: 0.2)
   ```

4. **Validation**:
   - Check for null values
   - Verify data types
   - Confirm value ranges
   - Review class balance

### Using Gemini to Test the Data

**Integration Process:**

1. **Setup** (Already configured in app):
   ```swift
   let vertex = VertexAI.vertexAI()
   let model = vertex.generativeModel(modelName: "gemini-1.5-flash")
   ```

2. **Training Phase**:
   - App sends training data to Gemini via prompt
   - Gemini analyzes patterns and relationships
   - Returns insights about learned patterns

3. **Testing Phase**:
   - For each test sample, send user profile to Gemini
   - Gemini predicts workout success based on learned patterns
   - App compares predictions to actual outcomes

4. **Prediction Request Format**:
   ```
   Input: User profile + learned patterns
   Output: JSON with success predictions
   ```

**Example Test Flow:**
```
Test Sample: 25yo, 70kg, 175cm, Beginner, Week duration
Gemini Prediction: 85% completion, difficulty 3, safety 0.92
Actual Outcome: 80% completion, no injury
Result: True Positive ✓
```

### Key Observations

**What Worked Well:**

1. **Gemini Integration**: 
   - Zero-configuration ML model
   - Natural language understanding of user profiles
   - Explainable predictions
   - Fast inference times

2. **Firebase Ecosystem**:
   - Seamless data flow from app to model
   - Real-time data collection
   - Automatic synchronization

3. **User Feedback Loop**:
   - Easy-to-use feedback interface
   - Swipe gesture for quick access
   - Gamified with star ratings

4. **Preprocessing Pipeline**:
   - Automatic outlier removal
   - Class balancing prevents bias
   - Maintains data quality

**What Didn't Work / Challenges:**

1. **Cold Start Problem**:
   - Model requires minimum 50-100 samples for reasonable accuracy
   - Early predictions may be unreliable
   - **Solution**: Use synthetic data for initial testing, clearly communicate to users

2. **Prompt Sensitivity**:
   - Gemini responses vary slightly with prompt wording
   - JSON parsing can fail if format changes
   - **Solution**: Strict JSON format requirements, fallback to default predictions

3. **Data Collection Speed**:
   - Real users take time to complete workouts and provide feedback
   - **Solution**: Implement referral system, incentivize feedback with features

4. **Gemini Cost at Scale**:
   - Firebase free tier has limits
   - Many predictions could incur costs
   - **Solution**: Cache predictions for similar profiles, batch processing

5. **Evaluation Metric Interpretation**:
   - Users may not understand precision/recall
   - **Solution**: Add plain-language explanations in UI

### Challenges Overcome

1. **Challenge**: Gemini doesn't provide traditional "training"
   **Solution**: Used few-shot learning with prompt engineering to simulate training

2. **Challenge**: Inconsistent JSON responses from Gemini
   **Solution**: Added robust JSON cleaning and error handling with fallback values

3. **Challenge**: Small dataset initially
   **Solution**: Implemented data balancing and augmentation techniques

4. **Challenge**: User engagement with feedback
   **Solution**: Added swipe gestures and made feedback optional but incentivized

### Future Improvements

1. **Enhanced Features**:
   - A/B testing different prompts for better accuracy
   - Personalized workout recommendations based on past success
   - Injury risk prediction with warnings
   - Progress tracking over time

2. **Model Enhancements**:
   - Ensemble approach with multiple AI models
   - Fine-tuning on larger datasets
   - Continuous learning from new feedback

3. **Data Quality**:
   - Add data validation at submission
   - Implement fraud detection for fake feedback
   - Rich media (photos, videos) in feedback

4. **Evaluation**:
   - Cross-validation for more robust metrics
   - Longitudinal studies of user success
   - Comparison with human trainer recommendations

---

## File Structure

```
WorkoutAIApp/
├── ML/
│   ├── DataCollectionService.swift          # Collect user feedback data
│   ├── WorkoutRecommendationModel.swift     # Gemini integration & training/testing
│   └── DataPreprocessor.swift               # Data cleaning & preparation
├── Views/
│   ├── ModelEvaluationView.swift            # Display metrics & confusion matrix
│   └── WorkoutFeedbackView.swift            # User feedback submission form
└── Models/
    └── (Existing models updated with feedback support)
```

---

## Running the ML Pipeline

1. **Collect Data**: Users use app and submit feedback
2. **Open ML Tab**: Navigate to "ML Model" tab in app
3. **View Dataset**: Check total samples collected
4. **Export Data**: Optional - export CSV for external analysis
5. **Train & Test**: Tap "Train & Test Model" button
6. **View Results**: See accuracy, precision, recall, F1 score, confusion matrix

---

## Success Criteria

- ✅ Minimum 100 training samples
- ✅ Accuracy ≥75%
- ✅ Precision ≥70%
- ✅ Recall ≥70%
- ✅ F1 Score ≥70%
- ✅ Confusion matrix visualization
- ✅ Real-time evaluation metrics

---

## Conclusion

This ML pipeline successfully integrates Google Gemini with the Workout AI app to create a practical recommendation system. By collecting real user feedback and using Gemini's reasoning capabilities, the system learns which workout plans work best for different user profiles. The complete implementation includes data collection, preprocessing, training, testing, and comprehensive evaluation metrics—all within a user-friendly iOS app.
